package task06;

public class Student {
    int ID;
    String name;
    public Student(int iD, String name) {
        ID = iD;
        this.name = name;
    }
    
}
