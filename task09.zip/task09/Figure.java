package task09;

public interface Figure{
    public double getArea();
    public double getPerimeter();
}
    